<?php sleep(5);?>

<span>salut t'as pplus de 18 ans mec </span>